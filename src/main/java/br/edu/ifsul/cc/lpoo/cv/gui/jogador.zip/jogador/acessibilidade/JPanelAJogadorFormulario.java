package br.edu.ifsul.cc.lpoo.cs.gui.jogador.acessibilidade;

import br.edu.ifsul.cc.lpoo.cs.Controle;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

/**
 *
 * @author telmo
 */
public class JPanelAJogadorFormulario extends JPanel implements ActionListener{
    
    
    private JPanelAJogador pnlAJogador;
    private Controle controle;
    
    private BorderLayout borderLayout;
    private JTabbedPane tbpAbas;
    
    private JPanel pnlDadosCadastrais;    
    private JPanel pnlCentroDadosCadastrais;
    
    private GridBagLayout gridBagLayoutDadosCadastrais;
    private JLabel lblNickname;
    private JTextField txfNickname;
    
    private JPanel pnlSul;
    private JButton btnGravar;
    private JButton btnCancelar;
    
    private JPanel pnlDadosCompras;
    private JPanel pnlDadosArtefatos;
    private JPanel pnlDadosPatentes;

    
    
    public JPanelAJogadorFormulario(JPanelAJogador pnlAJogador, Controle controle){
        
        this.pnlAJogador = pnlAJogador;
        this.controle = controle;
        
        initComponents();
        
    }
    
    private void initComponents(){
        
        borderLayout = new BorderLayout();
        this.setLayout(borderLayout);
        
        tbpAbas = new JTabbedPane();
        this.add(tbpAbas, BorderLayout.CENTER);
        
        pnlDadosCadastrais = new JPanel();
        gridBagLayoutDadosCadastrais = new GridBagLayout();
        pnlDadosCadastrais.setLayout(gridBagLayoutDadosCadastrais);
        
        lblNickname = new JLabel("Nickname:");
        GridBagConstraints posicionador = new GridBagConstraints();
        posicionador.gridy = 0;//policao da linha (vertical)
        posicionador.gridx = 0;// posição da coluna (horizontal)
        pnlDadosCadastrais.add(lblNickname, posicionador);//o add adiciona o rotulo no painel  
        
        txfNickname = new JTextField(20);
        posicionador = new GridBagConstraints();
        posicionador.gridy = 0;//policao da linha (vertical)
        posicionador.gridx = 1;// posição da coluna (horizontal)
        pnlDadosCadastrais.add(txfNickname, posicionador);//o add adiciona o rotulo no painel  
        
        tbpAbas.addTab("Dados Cadastrais", pnlDadosCadastrais);
        
        pnlDadosCompras = new JPanel();
        tbpAbas.addTab("Compras", pnlDadosCompras);
        
        
        pnlDadosArtefatos = new JPanel();
        tbpAbas.addTab("Artefatos", pnlDadosArtefatos);
        
        
        pnlDadosPatentes = new JPanel();
        tbpAbas.addTab("Patentes", pnlDadosPatentes);
        
        
        pnlSul = new JPanel();
        pnlSul.setLayout(new FlowLayout());
        
        btnGravar = new JButton("Gravar");
        btnGravar.addActionListener(this);
        btnGravar.setFocusable(true);    //acessibilidade    
        btnGravar.setToolTipText("btnGravarJogador"); //acessibilidade
        btnGravar.setMnemonic(KeyEvent.VK_G);
        btnGravar.setActionCommand("botao_gravar_formulario_jogador");
        
        pnlSul.add(btnGravar);
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(this);
        btnCancelar.setFocusable(true);    //acessibilidade    
        btnCancelar.setToolTipText("btnCancelarJogador"); //acessibilidade
        btnCancelar.setActionCommand("botao_cancelar_formulario_jogador");
        
        pnlSul.add(btnCancelar);
        
        this.add(pnlSul, BorderLayout.SOUTH);
        
    }

    @Override
    public void actionPerformed(ActionEvent arg0) {
        if(arg0.getActionCommand().equals(btnGravar.getActionCommand())){
            
            pnlAJogador.showTela("tela_jogador_listagem");
            
            
        }else if(arg0.getActionCommand().equals(btnCancelar.getActionCommand())){
            
        }
    }
}
