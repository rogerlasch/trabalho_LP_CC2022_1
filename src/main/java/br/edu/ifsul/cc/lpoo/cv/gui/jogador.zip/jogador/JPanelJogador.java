
package br.edu.ifsul.cc.lpoo.cs.gui.jogador;

import br.edu.ifsul.cc.lpoo.cs.Controle;
import java.awt.CardLayout;
import javax.swing.JPanel;

/**
 *
 * @author telmo
 */
public class JPanelJogador extends JPanel {
    
    private CardLayout cardLayout;
    private Controle controle;
    
    
    public JPanelJogador(Controle controle){
        
        this.controle = controle;
        initComponents();
    }
    
    private void initComponents(){
        
        cardLayout = new CardLayout();
        this.setLayout(cardLayout);
        
    }
    
    public void showTela(String nomeTela){
        
        cardLayout.show(this, nomeTela);
    }

    /**
     * @return the controle
     */
    public Controle getControle() {
        return controle;
    }
    
}
